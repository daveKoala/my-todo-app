<?php

use Illuminate\Support\Facades\Route;
use DaveKoala\RoutesExplorer\Http\Controllers\ExplorerController;

Route::get('/dev/routes-explorer', [ExplorerController::class, 'index']);
