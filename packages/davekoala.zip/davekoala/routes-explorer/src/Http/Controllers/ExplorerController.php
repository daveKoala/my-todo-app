<?php

namespace DaveKoala\RoutesExplorer\Http\Controllers;

use Illuminate\Routing\Controller;

class ExplorerController extends Controller
{
    public function index()
    {
        return '<h1>Routes Explorer</h1><p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>';
    }
}
