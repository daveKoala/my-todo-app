<?php

namespace DaveKoala\RoutesExplorer;

use Illuminate\Support\ServiceProvider;
use Illuminate\Support\Facades\Route;

class RoutesExplorerServiceProvider extends ServiceProvider
{
    public function boot()
    {
        $this->loadRoutesFrom(__DIR__ . '/routes/web.php');
    }

    public function register()
    {
        //
    }
}
